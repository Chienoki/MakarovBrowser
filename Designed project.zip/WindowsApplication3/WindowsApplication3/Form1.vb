﻿Public Class Form1
    Private txtUrl As Object
    Private ReadOnly document As Object

    Private Sub ToolStripTextBox1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub ToolStripTextBox2_LoadByVal(sender As System.Object, ByVal e As System.EventArgs)
        txtUrl.Text = "https://www.google.com/ncr"
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs)
        If txtUrl.Text <> String.Empty Then
            Me.WebBrowser1.Navigate(txtUrl.Text)
        End If
    End Sub

    Private Sub ToolStripTextBox2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ToolStripTextBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ToolStripTextBox2_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub ToolStripTextBox1_Click_1(sender As Object, e As EventArgs) 

    End Sub
End Class
